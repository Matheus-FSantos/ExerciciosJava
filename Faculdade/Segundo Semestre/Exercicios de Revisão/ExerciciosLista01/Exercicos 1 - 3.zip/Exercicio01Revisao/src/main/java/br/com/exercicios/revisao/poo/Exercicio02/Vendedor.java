/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.exercicios.revisao.poo.Exercicio02;

/**
 *
 * @author matheus.fsantos52
 */
public class Vendedor {
    public static int incremento = 0;
    
    private int id;
    private String nome;
    
    public Vendedor(String nome){
        ++incremento;
        
        id = incremento;
        this.nome = nome.toUpperCase();
    }
    
    public int getId(){
        return id;
    }
    
    public void setId(int id){
        this.id = id;
    }
    
    public String getNome(){
        return nome;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
}