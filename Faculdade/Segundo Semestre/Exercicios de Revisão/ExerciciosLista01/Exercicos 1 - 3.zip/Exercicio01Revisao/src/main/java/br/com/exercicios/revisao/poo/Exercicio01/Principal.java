/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.exercicios.revisao.poo.Exercicio01;
import br.com.exercicios.revisao.poo.Exercicio01.Funcionario;
import javax.swing.JOptionPane;
/**
 *
 * @author matheus.fsantos52
 */
public class Principal {
    public static void main(String[] args) {
        Funcionario funcionarios[] = new Funcionario[2];
        float total = 0;
        float maior = 0;
        int quantidade = 0;
        
        for(int i = 0; i < funcionarios.length; i++){
            Funcionario f1 = new Funcionario(JOptionPane.showInputDialog("Informe o nome do funcionario").toUpperCase(), Float.parseFloat(JOptionPane.showInputDialog("Informe o salario do funcionario")));
            total = salarioMedio(f1.getSalario(), total);
            maior = salarioMaior(f1.getSalario(), maior);
            quantidade = salariosMaiorQue850(f1.getSalario(), quantidade);
            funcionarios[i] = f1;
        }
        
        total = total /10; //calcula o salario medio
        System.out.println("\nMédia salarial: " + total +
                           "\nMaior salario: " + maior +
                           "\nQuantidade de salarios maior que 850: " + quantidade);
    }
    
    private static float salarioMedio(float salario, float total){
        total = salario + total;
        
        return total;
    }

    private static float salarioMaior(float salario, float maior) {
        if(salario > maior)
            maior = salario;
        
        return maior;
    }

    private static int salariosMaiorQue850(float salario, int quantidade) {
        if(salario > 850)
            quantidade = quantidade + 1;
        
        return quantidade;
    }
}