/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.exercicios.revisao.poo.Exercicio02;
import javax.swing.JOptionPane;
/**
 *
 * @author matheus.fsantos52
 */
public class Venda {
    public static void main(String[] args) {
        int quantidade = Integer.parseInt(JOptionPane.showInputDialog("Informe a quantidade de vendedores que deseja cadastrar"));
        Pecas vendas[] = new Pecas[quantidade];
        
        float totalPecas = 0;
        int quantidadeDePecas = 0;
        
        for(int i = 0; i < vendas.length; i++){
            Vendedor v = new Vendedor(JOptionPane.showInputDialog("Informe o nome do " + (i + 1) + "º vendedor"));
            Pecas p = new Pecas(JOptionPane.showInputDialog("Informe o nome da peça"), 
                                Integer.parseInt(JOptionPane.showInputDialog("Informe a quantidade em estoque")),
                                Float.parseFloat(JOptionPane.showInputDialog("Informe o preço da peça")),
                                v);
            p.valorDaVenda();
            quantidadeDePecas = Pecas.quantidadeDePecas;
            totalPecas = Pecas.valorTotalPecas;
            
            vendas[i] = p;
        }
        
        System.out.println("Dados");        
        for(int i = 0; i < vendas.length; i++){
            System.out.println("\n" + vendas[i]);
            System.out.println();
        }
        
        System.out.println("\n\nTotal de peças vendidas: " + quantidadeDePecas + "\nPreco total das peças: " + totalPecas);
                
    }
}