/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.exercicios.revisao;
import javax.swing.JOptionPane;
/**
 *
 * @author matheus.fsantos52
 */
public class Exercicio03Revisao {
    public static void main(String[] args) {
        String nomes[] = new String[2];
        char generos[] = new char[nomes.length];
        float salarios[] = new float[nomes.length];
        
        inserirDados(nomes, generos, salarios);
        menorSalario(nomes, generos, salarios);
        imprimirDados(nomes, generos, salarios);
        float salarioMulheres = mediaMulheres(generos, salarios);
        int quantidadeHomens1000 = homensMaiosDe1000(generos, salarios);
        
        System.out.println("\nMedia salarial das mulheres: " + salarioMulheres + "\nQuantidade de homens que ganham mais de 1000: " + quantidadeHomens1000);
    }

    private static void inserirDados(String[] nomes, char[] generos, float[] salarios) {
        for(int i = 0; i < nomes.length; i++){
            nomes[i] = JOptionPane.showInputDialog("Informe o nome do funcionario").toUpperCase();
            generos[i] = JOptionPane.showInputDialog("Informe o genero do funcionario " + nomes[i] + "\n\nOBS\n\nF - Feminino\nM - Masculino").toUpperCase().charAt(0);
            salarios[i] = Float.parseFloat(JOptionPane.showInputDialog("Informe o salario do funcionario " + nomes[i]));
        }
    }

    private static void imprimirDados(String[] nomes, char[] generos, float[] salarios) {
        System.out.println("-------------------------------");
        System.out.println("Dados dos funcionarios da empresa\n");
        for(int i = 0; i < nomes.length; i++){
            System.out.println("ID: " + (i + 1) + "\nFuncionario: " + nomes[i] + "\nGenero: " + generos[i] + "\nSalario: " + salarios[i]);
            System.out.println();
        }
        System.out.println("-------------------------------");
        System.out.println();
    }
    
    private static void imprimirDados(String[] nomes, char[] generos, float[] salarios, int indice) {
        System.out.println("-------------------------------");
        System.out.println("Dados do menor salario da empresa\n");
        System.out.println("ID: " + (indice + 1) + "\nFuncionario: " + nomes[indice] + "\nGenero: " + generos[indice] + "\nSalario: " + salarios[indice]);
        System.out.println("-------------------------------");
        System.out.println();
    }

    private static float mediaMulheres(char[] generos, float[] salarios) {
        int quantidade = 0;
        float total = 0;
        
        for(int i = 0; i < generos.length; i++){
            if(generos[i] == 'F'){
                ++quantidade;
                total = total + salarios[i];
            }
        }
        
        return total = total/quantidade;
    }

    private static void menorSalario(String[] nomes, char[] generos, float[] salarios) {
        float maior = 0;
        int indice = 0;
        
        for(int i = 0; i < salarios.length; i++){
            if(maior > salarios[i]){
                indice = i + 1;
                maior = salarios[i];
            }
        }
        
        imprimirDados(nomes, generos, salarios, indice);
    }

    private static int homensMaiosDe1000(char[] generos, float[] salarios) {
        int quantidade = 0;
        
        for(int i = 0; i < generos.length; i++){
            if(generos[i] == 'M'){
                if (salarios[i] > 1000)
                    ++quantidade;
            }
        }
        
        return quantidade;
    }
}