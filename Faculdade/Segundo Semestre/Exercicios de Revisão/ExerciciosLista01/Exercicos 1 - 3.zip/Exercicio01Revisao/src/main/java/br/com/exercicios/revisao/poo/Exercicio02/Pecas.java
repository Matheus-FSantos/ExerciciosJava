/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.exercicios.revisao.poo.Exercicio02;

/**
 *
 * @author matheus.fsantos52
 */
public class Pecas {
    public static int incremento = 0;
    public static int quantidadeDePecas = 0;
    public static float valorTotalPecas = 0;
    
    private int id;
    private String descricao;
    private int quantidade;
    private float preco;
    private Vendedor vendedor;
    private float totalDaVenda;
    
    public Pecas(String descricao, int quantidade, float preco, Vendedor vendedor){
        ++quantidadeDePecas; //quantidade de pecas
        ++incremento;
        id = incremento;
        
        this.descricao = descricao.toUpperCase();
        this.quantidade = quantidade;
        this.preco = preco;
        this.vendedor = vendedor;
        
        valorTotalPecas = (valorTotalPecas + preco); //valor das pecas
    }
    
    @Override
    public String toString(){
        return "Vendedor: " + vendedor.getNome()+
               "\nId da peça: " + this.getId() +
               "\nPeça: " + this.getDescricao() +
               "\nQuantidade em estoque: " + this.getQuantidade() +
               "\nPreço: R$" + this.getPreco() +
               "\nTotal da venda: " + getTotalDaVenda();
    }
    
    //valor da venda por si só
    public void valorDaVenda(){
        setTotalDaVenda(getQuantidade() * getPreco());
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public Vendedor getVendedor() {
        return vendedor;
    }

    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }
    
    public float getTotalDaVenda() {
        return totalDaVenda;
    }

    public void setTotalDaVenda(float totalDaVenda) {
        this.totalDaVenda = totalDaVenda;
    }
}