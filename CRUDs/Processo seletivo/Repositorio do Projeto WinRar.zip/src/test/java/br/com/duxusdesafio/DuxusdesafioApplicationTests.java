package br.com.duxusdesafio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DuxusdesafioApplicationTests {

	@Test
	void contextLoads() {
	}

}
