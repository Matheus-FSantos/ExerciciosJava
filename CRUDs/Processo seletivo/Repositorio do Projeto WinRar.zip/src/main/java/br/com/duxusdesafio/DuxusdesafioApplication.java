package br.com.duxusdesafio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DuxusdesafioApplication {

	public static void main(String[] args) {
		SpringApplication.run(DuxusdesafioApplication.class, args);
	}

}
